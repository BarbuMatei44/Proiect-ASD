# Piese Auto (Django) - v8
Pagina de start, anunțuri, cereri de piese și oferte ("fulfill").

    python -m venv venv
    venv\Scripts\activate        # Mac/Linux: source venv/bin/activate
    pip install -r requirements.txt
    python manage.py migrate
    python manage.py seed        # opțional: anunțuri și cereri fictive
    python manage.py createsuperuser
    python manage.py runserver
Deschide http://127.0.0.1:8000

## Pornire rapida
Windows: dublu-click pe start.bat. Mac/Linux: start.command. Vezi CITESTE-MA.txt.

## Dashboard
Disponibil la /dashboard/ doar pentru conturi staff (createsuperuser creează unul).
Un utilizator existent devine staff cu:
    python manage.py shell -c "from django.contrib.auth import get_user_model as g; u=g().objects.get(username='NUME'); u.is_staff=True; u.save()"

## Contul meu
Orice utilizator autentificat își vede vânzările și cumpărările la /contul-meu/ (perioadă, grafice, tabele, export CSV).

## Reguli la crearea contului
Nume de utilizator: 4-20 caractere (litere fără diacritice, cifre, . _ -).
Parolă: minim 8 caractere, literă mare, literă mică, cifră și caracter special.
Regulile sunt verificate și în browser (cu bife), și pe server.
