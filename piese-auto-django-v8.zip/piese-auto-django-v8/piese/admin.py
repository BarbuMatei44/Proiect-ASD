from django.contrib import admin
from .models import Anunt, Cerere, Oferta


@admin.register(Anunt)
class AnuntAdmin(admin.ModelAdmin):
    list_display = ("titlu", "marca", "model", "pret", "user", "creat")
    search_fields = ("titlu", "cod_piesa", "marca")
    list_filter = ("categorie", "stare")


@admin.register(Cerere)
class CerereAdmin(admin.ModelAdmin):
    list_display = ("titlu", "marca", "model", "buget", "status", "user", "creat")
    search_fields = ("titlu", "cod_piesa", "marca")
    list_filter = ("categorie", "status")


@admin.register(Oferta)
class OfertaAdmin(admin.ModelAdmin):
    list_display = ("cerere", "user", "pret", "acceptata", "creat")


from .models import Vanzare  # noqa: E402


@admin.register(Vanzare)
class VanzareAdmin(admin.ModelAdmin):
    list_display = ("titlu", "pret", "vanzator", "cumparator", "sursa", "creat")
    list_filter = ("sursa", "categorie")
    search_fields = ("titlu", "vanzator__username", "cumparator__username")
