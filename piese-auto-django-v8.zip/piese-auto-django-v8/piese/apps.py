from django.apps import AppConfig

class PieseConfig(AppConfig):
    name = "piese"
