"""Dashboard de administrare: vânzări, perioade, top vânzători/cumpărători. Doar pentru staff."""
import csv
from datetime import date, timedelta
from decimal import Decimal
from functools import wraps
from math import ceil

from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.db.models import Avg, Count, Q, Sum
from django.db.models.functions import TruncDate, TruncMonth
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.urls import reverse
from django.utils import timezone

from .models import Anunt, Cerere, Oferta, Vanzare

PRESETURI = [("7", "7 zile"), ("30", "30 de zile"), ("90", "90 de zile"),
             ("luna", "Luna aceasta"), ("an", "Anul acesta"), ("tot", "Tot timpul")]


def doar_staff(view):
    @wraps(view)
    def w(request, *a, **k):
        if not request.user.is_authenticated:
            return redirect(f"{reverse('login')}?next={request.path}")
        if not request.user.is_staff:
            raise PermissionDenied
        return view(request, *a, **k)
    return w


def interval(g):
    """Returnează (cheie, început, sfârșit); capetele None înseamnă fără limită."""
    azi = timezone.localdate()
    try:
        de_la = date.fromisoformat(g["de_la"]) if g.get("de_la") else None
        pana_la = date.fromisoformat(g["pana_la"]) if g.get("pana_la") else None
    except ValueError:
        de_la = pana_la = None
    if de_la or pana_la:
        if de_la and pana_la and de_la > pana_la:
            de_la, pana_la = pana_la, de_la
        return "custom", de_la, pana_la
    p = g.get("perioada", "30")
    if p == "7":
        return p, azi - timedelta(days=6), azi
    if p == "90":
        return p, azi - timedelta(days=89), azi
    if p == "luna":
        return p, azi.replace(day=1), azi
    if p == "an":
        return p, date(azi.year, 1, 1), azi
    if p == "tot":
        return p, None, None
    return "30", azi - timedelta(days=29), azi


def in_perioada(qs, start, end, camp="creat"):
    if start:
        qs = qs.filter(**{f"{camp}__date__gte": start})
    if end:
        qs = qs.filter(**{f"{camp}__date__lte": end})
    return qs


def delta(cur, prev):
    if not prev:
        return None
    return round((cur - prev) / prev * 100)


def serie(v, start, end):
    """Puncte pentru graficul de vânzări: pe zile (perioade scurte) sau pe luni."""
    end = end or timezone.localdate()
    if not start:
        prima = v.order_by("creat").values_list("creat", flat=True).first()
        if not prima:
            return []
        start = timezone.localtime(prima).date()
    puncte = []
    if (end - start).days + 1 <= 62:
        dati = {r["d"]: r for r in v.annotate(d=TruncDate("creat")).values("d")
                .annotate(n=Count("id"), total=Sum("pret")).order_by()}
        d = start
        while d <= end:
            r = dati.get(d)
            puncte.append({"eticheta": d.strftime("%d.%m"), "n": r["n"] if r else 0,
                           "total": (r["total"] or 0) if r else 0})
            d += timedelta(days=1)
    else:
        dati = {(r["m"].year, r["m"].month): r for r in v.annotate(m=TruncMonth("creat")).values("m")
                .annotate(n=Count("id"), total=Sum("pret")).order_by()}
        y, m = start.year, start.month
        while (y, m) <= (end.year, end.month):
            r = dati.get((y, m))
            puncte.append({"eticheta": f"{m:02d}.{y}", "n": r["n"] if r else 0,
                           "total": (r["total"] or 0) if r else 0})
            m += 1
            if m == 13:
                y, m = y + 1, 1
    mx = max([float(p["total"]) for p in puncte], default=0)
    pas = max(1, ceil(len(puncte) / 12))
    for i, p in enumerate(puncte):
        p["h"] = max(3, int(float(p["total"]) / mx * 100)) if mx and p["total"] else 0
        p["arata"] = i % pas == 0
    return puncte


def top(v, camp):
    rows = (v.exclude(**{camp: None}).values(camp, f"{camp}__username")
            .annotate(n=Count("id"), total=Sum("pret")).order_by("-total")[:10])
    return [{"id": r[camp], "nume": r[f"{camp}__username"], "n": r["n"], "total": r["total"]} for r in rows]


def grupeaza(v, camp, limita=8):
    rows = list(v.exclude(**{camp: ""}).values(camp)
                .annotate(n=Count("id"), total=Sum("pret")).order_by("-total")[:limita])
    mx = max([float(r["total"]) for r in rows], default=0)
    return [{"nume": r[camp], "n": r["n"], "total": r["total"],
             "w": int(float(r["total"]) / mx * 100) if mx else 0} for r in rows]


def _date(request):
    g = request.GET
    cheie, start, end = interval(g)
    v = in_perioada(Vanzare.objects.all(), start, end)
    utilizator = None
    if g.get("utilizator", "").isdigit():
        utilizator = get_user_model().objects.filter(pk=g["utilizator"]).first()
    vf = v.filter(Q(vanzator=utilizator) | Q(cumparator=utilizator)) if utilizator else v
    return g, cheie, start, end, v, vf, utilizator


@doar_staff
def panou(request):
    User = get_user_model()
    g, cheie, start, end, v, vf, utilizator = _date(request)

    agg = vf.aggregate(n=Count("id"), total=Sum("pret"), medie=Avg("pret"))
    kpi = {"n": agg["n"] or 0, "total": agg["total"] or Decimal(0), "medie": agg["medie"] or Decimal(0),
           "d_n": None, "d_total": None}
    if start and end:
        zile = (end - start).days + 1
        prev = in_perioada(Vanzare.objects.all(), start - timedelta(days=zile), start - timedelta(days=1))
        if utilizator:
            prev = prev.filter(Q(vanzator=utilizator) | Q(cumparator=utilizator))
        pa = prev.aggregate(n=Count("id"), total=Sum("pret"))
        kpi["d_n"] = delta(kpi["n"], pa["n"])
        kpi["d_total"] = delta(kpi["total"], pa["total"])

    platforma = {
        "anunturi": in_perioada(Anunt.objects.all(), start, end).count(),
        "cereri": in_perioada(Cerere.objects.all(), start, end).count(),
        "utilizatori": in_perioada(User.objects.all(), start, end, "date_joined").count(),
        "anunturi_active": Anunt.objects.filter(vandut=False).count(),
        "cereri_deschise": Cerere.objects.filter(status="deschisa").count(),
    }

    rezumat_user = None
    if utilizator:
        rezumat_user = {
            "vanzator": v.filter(vanzator=utilizator).aggregate(n=Count("id"), total=Sum("pret")),
            "cumparator": v.filter(cumparator=utilizator).aggregate(n=Count("id"), total=Sum("pret")),
        }

    surse = {r["sursa"]: r["n"] for r in vf.values("sursa").annotate(n=Count("id")).order_by()}
    qs = g.copy()
    qs.pop("utilizator", None)

    return render(request, "dashboard.html", {
        "cheie": cheie, "preseturi": PRESETURI, "de_la": start if cheie == "custom" else None,
        "pana_la": end if cheie == "custom" else None, "kpi": kpi, "platforma": platforma,
        "puncte": serie(vf, start, end), "top_vanzatori": top(vf, "vanzator"),
        "top_cumparatori": top(vf, "cumparator"), "categorii": grupeaza(vf, "categorie"),
        "marci": grupeaza(vf, "marca"), "surse": surse, "utilizator": utilizator,
        "rezumat_user": rezumat_user, "qs": qs.urlencode(),
        "tranzactii": vf.select_related("vanzator", "cumparator").order_by("-creat")[:25],
    })


@doar_staff
def export_csv(request):
    *_, vf, _utilizator = _date(request)
    r = HttpResponse(content_type="text/csv; charset=utf-8")
    r["Content-Disposition"] = 'attachment; filename="piese-vanzari.csv"'
    r.write("\ufeff")  # ca Excel să recunoască diacriticele
    w = csv.writer(r, delimiter=";")
    w.writerow(["Data", "Piesă", "Categorie", "Marcă", "Vânzător", "Cumpărător", "Preț (lei)", "Sursă"])
    for t in vf.select_related("vanzator", "cumparator").order_by("-creat"):
        w.writerow([timezone.localtime(t.creat).strftime("%Y-%m-%d %H:%M"), t.titlu, t.categorie, t.marca,
                    t.vanzator.username if t.vanzator else "", t.cumparator.username if t.cumparator else "",
                    t.pret, t.get_sursa_display()])
    return r


# ---------- Contul meu: dashboard pentru utilizatori obișnuiți ----------
def _comparatie(v_user, start, end, camp):
    """Variația procentuală a valorii față de perioada anterioară de aceeași lungime."""
    if not (start and end):
        return None, None
    zile = (end - start).days + 1
    prev = in_perioada(Vanzare.objects.filter(**{camp: v_user}),
                       start - timedelta(days=zile), start - timedelta(days=1))
    pa = prev.aggregate(n=Count("id"), total=Sum("pret"))
    return pa["n"], pa["total"]


@login_required
def contul_meu(request):
    u = request.user
    cheie, start, end = interval(request.GET)
    v = in_perioada(Vanzare.objects.all(), start, end)
    vandute, cumparate = v.filter(vanzator=u), v.filter(cumparator=u)

    av = vandute.aggregate(n=Count("id"), total=Sum("pret"), medie=Avg("pret"))
    ac = cumparate.aggregate(n=Count("id"), total=Sum("pret"), medie=Avg("pret"))
    kv = {"n": av["n"] or 0, "total": av["total"] or Decimal(0), "medie": av["medie"] or Decimal(0)}
    kc = {"n": ac["n"] or 0, "total": ac["total"] or Decimal(0), "medie": ac["medie"] or Decimal(0)}
    pn, pt = _comparatie(u, start, end, "vanzator")
    kv["d_n"], kv["d_total"] = delta(kv["n"], pn), delta(kv["total"], pt)
    pn, pt = _comparatie(u, start, end, "cumparator")
    kc["d_n"], kc["d_total"] = delta(kc["n"], pn), delta(kc["total"], pt)

    cont = {
        "anunturi_active": u.anunturi.filter(vandut=False).count(),
        "anunturi_vandute": u.anunturi.filter(vandut=True).count(),
        "cereri_deschise": u.cereri.filter(status="deschisa").count(),
        "oferte_primite": Oferta.objects.filter(cerere__user=u, cerere__status="deschisa", acceptata=False).count(),
        "oferte_trimise": Oferta.objects.filter(user=u, cerere__status="deschisa", acceptata=False).count(),
    }
    return render(request, "contul_meu.html", {
        "cheie": cheie, "preseturi": PRESETURI,
        "de_la": start if cheie == "custom" else None, "pana_la": end if cheie == "custom" else None,
        "kv": kv, "kc": kc, "bilant": kv["total"] - kc["total"], "cont": cont,
        "puncte_v": serie(vandute, start, end), "puncte_c": serie(cumparate, start, end),
        "cat_v": grupeaza(vandute, "categorie"), "cat_c": grupeaza(cumparate, "categorie"),
        "tr_vandute": vandute.select_related("cumparator", "anunt", "cerere").order_by("-creat")[:25],
        "tr_cumparate": cumparate.select_related("vanzator", "anunt", "cerere").order_by("-creat")[:25],
    })


@login_required
def export_csv_meu(request):
    u = request.user
    _cheie, start, end = interval(request.GET)
    v = in_perioada(Vanzare.objects.filter(Q(vanzator=u) | Q(cumparator=u)), start, end)
    r = HttpResponse(content_type="text/csv; charset=utf-8")
    r["Content-Disposition"] = 'attachment; filename="tranzactiile-mele.csv"'
    r.write("\ufeff")
    w = csv.writer(r, delimiter=";")
    w.writerow(["Data", "Tip", "Piesă", "Categorie", "Marcă", "Cealaltă parte", "Preț (lei)", "Sursă"])
    for t in v.select_related("vanzator", "cumparator").order_by("-creat"):
        vand = t.vanzator_id == u.id
        altul = t.cumparator if vand else t.vanzator
        w.writerow([timezone.localtime(t.creat).strftime("%Y-%m-%d %H:%M"), "Vânzare" if vand else "Cumpărare",
                    t.titlu, t.categorie, t.marca, altul.username if altul else "din afara site-ului",
                    t.pret, t.get_sursa_display()])
    return r
