from datetime import date

from django import forms

from .models import Anunt, Cerere, Oferta
from .optiuni import MARCI, ORASE


class CampuriComune(forms.ModelForm):
    """Marcă, localitate și an: doar alegere din listă, fără scriere liberă."""
    marca = forms.ChoiceField(label="Marcă", choices=[("", "Alege marca")] + [(m, m) for m in MARCI])
    oras = forms.ChoiceField(label="Localitate", choices=[("", "Alege localitatea")] + [(o, o) for o in ORASE])
    an = forms.TypedChoiceField(label="An", required=False, coerce=int, empty_value=None, choices=[])

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        ani = range(date.today().year, 1969, -1)
        self.fields["an"].choices = [("", "Alege anul")] + [(a, a) for a in ani]


class AnuntForm(CampuriComune):
    class Meta:
        model = Anunt
        fields = ["titlu", "categorie", "stare", "marca", "model", "an", "cod_piesa",
                  "pret", "oras", "telefon", "imagine", "descriere"]


class CerereForm(CampuriComune):
    stare = forms.ChoiceField(label="Stare dorită", required=False, choices=[("", "Oricare")] + Anunt.STARI)
    buget = forms.DecimalField(label="Buget maxim (lei)", required=False, min_value=0, max_digits=9, decimal_places=2)

    class Meta:
        model = Cerere
        fields = ["titlu", "categorie", "stare", "marca", "model", "an", "cod_piesa",
                  "buget", "oras", "telefon", "descriere"]


class OfertaForm(forms.ModelForm):
    class Meta:
        model = Oferta
        fields = ["anunt", "pret", "telefon", "mesaj"]
        labels = {"anunt": "Leagă oferta de unul dintre anunțurile tale (opțional)", "mesaj": "Mesaj"}

    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["anunt"].queryset = Anunt.objects.filter(user=user) if user else Anunt.objects.none()
        self.fields["anunt"].empty_label = "Fără anunț legat"
        self.fields["anunt"].required = False

    def clean_pret(self):
        pret = self.cleaned_data["pret"]
        if pret < 0:
            raise forms.ValidationError("Prețul nu poate fi negativ.")
        return pret


class VandutForm(forms.Form):
    cumparator = forms.ModelChoiceField(
        label="Cumpărător", required=False, queryset=None,
        empty_label="Cumpărător din afara site-ului")
    pret = forms.DecimalField(label="Preț final (lei)", min_value=0, max_digits=9, decimal_places=2)

    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        from django.contrib.auth import get_user_model
        qs = get_user_model().objects.order_by("username")
        self.fields["cumparator"].queryset = qs.exclude(pk=user.pk) if user else qs


import re  # noqa: E402

from django.contrib.auth import get_user_model  # noqa: E402
from django.contrib.auth.forms import UserCreationForm  # noqa: E402

USER_MIN, USER_MAX = 4, 20


class InregistrareForm(UserCreationForm):
    username = forms.CharField(
        label="Nume de utilizator", min_length=USER_MIN, max_length=USER_MAX,
        widget=forms.TextInput(attrs={"autocomplete": "username", "autofocus": True}),
        error_messages={"min_length": f"Folosește între {USER_MIN} și {USER_MAX} de caractere.",
                        "max_length": f"Folosește între {USER_MIN} și {USER_MAX} de caractere."})

    class Meta(UserCreationForm.Meta):
        model = get_user_model()
        fields = ("username",)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["password1"].label = "Parolă"
        self.fields["password1"].help_text = ""
        self.fields["password2"].label = "Confirmă parola"
        self.fields["password2"].help_text = ""

    def clean_username(self):
        nume = self.cleaned_data["username"].strip()
        if not re.fullmatch(r"[A-Za-z0-9_.-]+", nume):
            raise forms.ValidationError("Folosește doar litere (fără diacritice), cifre și caracterele . _ -")
        if get_user_model().objects.filter(username__iexact=nume).exists():
            raise forms.ValidationError("Acest nume de utilizator este deja folosit.")
        return nume
