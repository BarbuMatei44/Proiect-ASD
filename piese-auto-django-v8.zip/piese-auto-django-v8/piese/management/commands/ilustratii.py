"""Ilustrații desenate în cod pentru fiecare tip de piesă (necesită Pillow)."""
import math
from PIL import Image, ImageDraw

W, H = 800, 600
BG, METAL, DARK, MID, LIGHT, ACC = "#e9ecef", "#8d99a3", "#2b3238", "#5b6770", "#c3ccd3", "#e3a600"


def _c(d, c, r, fill=None, outline=None, width=1):
    d.ellipse([c[0] - r, c[1] - r, c[0] + r, c[1] + r], fill=fill, outline=outline, width=width)


def _pol(c, r, deg):
    a = math.radians(deg)
    return (c[0] + r * math.cos(a), c[1] + r * math.sin(a))


def disc(d):
    c = (400, 300)
    _c(d, c, 250, METAL, DARK, 6); _c(d, c, 228, LIGHT, DARK, 2)
    for r in (205, 180, 155):
        _c(d, c, r, None, METAL, 2)
    _c(d, c, 125, MID, DARK, 5); _c(d, c, 38, BG, DARK, 4)
    for k in range(5):
        _c(d, _pol(c, 80, k * 72 - 90), 14, BG, DARK, 3)


def pads(d):
    for y in (130, 340):
        d.rounded_rectangle([110, y, 690, y + 130], 24, fill=MID, outline=DARK, width=5)
        d.rounded_rectangle([170, y + 22, 630, y + 108], 12, fill="#6b5a4a", outline=DARK, width=3)
        for x in (140, 660):
            _c(d, (x, y + 65), 10, BG, DARK, 3)
        d.line([(400, y + 22), (400, y + 108)], fill=DARK, width=4)


def alternator(d):
    d.rounded_rectangle([200, 170, 560, 430], 40, fill=MID, outline=DARK, width=6)
    for x in range(250, 520, 40):
        d.line([(x, 200), (x, 400)], fill=DARK, width=5)
    d.rounded_rectangle([540, 190, 630, 410], 20, fill=METAL, outline=DARK, width=5)
    d.rectangle([630, 285, 665, 315], fill=LIGHT, outline=DARK, width=3)
    _c(d, (710, 300), 75, METAL, DARK, 5); _c(d, (710, 300), 50, LIGHT, DARK, 3); _c(d, (710, 300), 16, DARK)
    for p in ((250, 150), (480, 455)):
        _c(d, p, 34, METAL, DARK, 5); _c(d, p, 12, BG, DARK, 3)
    d.rectangle([160, 255, 200, 300], fill=ACC, outline=DARK, width=3)


def far(d):
    d.polygon([(110, 230), (560, 150), (700, 200), (700, 400), (560, 450), (110, 380)], fill=LIGHT, outline=DARK, width=6)
    _c(d, (290, 270), 68, DARK); _c(d, (290, 270), 50, "#9fb4c4"); _c(d, (290, 270), 22, "#dce6ee")
    _c(d, (490, 270), 48, DARK); _c(d, (490, 270), 34, "#9fb4c4"); _c(d, (490, 270), 14, "#dce6ee")
    d.line([(170, 360), (610, 390)], fill=ACC, width=14)
    d.rectangle([560, 440, 620, 500], fill=DARK)


def amortizor(d):
    d.rectangle([365, 250, 435, 520], fill=MID, outline=DARK, width=5)
    d.rectangle([390, 70, 410, 260], fill=LIGHT, outline=DARK, width=3)
    for i in range(9):
        y = 190 + i * 34
        d.ellipse([320, y, 480, y + 44], outline=ACC, width=8)
    d.rounded_rectangle([340, 40, 460, 90], 10, fill=DARK)
    d.rounded_rectangle([340, 520, 460, 565], 10, fill=DARK); _c(d, (400, 542), 14, BG)


def distributie(d):
    d.rounded_rectangle([140, 140, 660, 470], 150, outline="#1f2529", width=24)
    for a in range(0, 360, 12):
        pass
    for p, r in (((270, 275), 78), ((530, 275), 78), ((400, 385), 56)):
        _c(d, p, r, METAL, DARK, 5); _c(d, p, r - 24, LIGHT, DARK, 3); _c(d, p, 14, DARK)
    _c(d, (400, 385), 56, None, ACC, 6)


def capota(d):
    d.polygon([(160, 120), (640, 120), (730, 470), (70, 470)], fill=METAL, outline=DARK, width=6)
    d.line([(300, 125), (255, 465)], fill=LIGHT, width=8); d.line([(500, 125), (545, 465)], fill=LIGHT, width=8)
    d.polygon([(220, 200), (580, 200), (610, 420), (190, 420)], outline=MID, width=3)
    for x in (270, 530):
        _c(d, (x, 148), 7, DARK)
    d.rectangle([90, 450, 170, 490], fill=DARK); d.rectangle([630, 450, 710, 490], fill=DARK)


def janta(d):
    c = (400, 300)
    _c(d, c, 250, DARK); _c(d, c, 232, LIGHT, DARK, 3); _c(d, c, 205, "#3a444c")
    for k in range(5):
        a = k * 72 - 90
        d.polygon([_pol(c, 55, a - 16), _pol(c, 205, a - 10), _pol(c, 205, a + 10), _pol(c, 55, a + 16)], fill=LIGHT, outline=DARK, width=3)
    _c(d, c, 62, LIGHT, DARK, 4); _c(d, c, 20, DARK)
    for k in range(5):
        _c(d, _pol(c, 40, k * 72 - 54), 6, BG, DARK, 2)


def anvelopa(d):
    c = (400, 300)
    _c(d, c, 250, "#1e2327")
    for k in range(60):
        d.line([_pol(c, 222, k * 6), _pol(c, 248, k * 6)], fill="#3a434a", width=9)
    _c(d, c, 205, "#2a3136"); d.arc([c[0] - 185, c[1] - 185, c[0] + 185, c[1] + 185], 200, 340, fill=LIGHT, width=6)
    _c(d, c, 150, BG, "#555e65", 10)


def volan(d):
    c = (400, 300)
    for p in ((-200, 20), (200, 20), (0, 200)):
        d.line([c, (c[0] + p[0], c[1] + p[1])], fill=DARK, width=46)
    _c(d, c, 245, None, DARK, 52); _c(d, c, 214, None, ACC, 3)
    _c(d, c, 88, DARK); _c(d, c, 58, MID, METAL, 4)
    d.rounded_rectangle([150, 285, 215, 330], 8, fill=MID); d.rounded_rectangle([585, 285, 650, 330], 8, fill=MID)


def radiator(d):
    d.rectangle([170, 150, 630, 450], fill=METAL, outline=DARK, width=5)
    for x in range(180, 630, 10):
        d.line([(x, 152), (x, 448)], fill=DARK, width=2)
    for y in range(200, 450, 50):
        d.line([(172, y), (628, y)], fill=LIGHT, width=2)
    for x in (100, 630):
        d.rounded_rectangle([x, 130, x + 70, 470], 16, fill=MID, outline=DARK, width=5)
    d.rectangle([50, 170, 100, 210], fill=DARK); d.rectangle([700, 400, 750, 440], fill=DARK)
    _c(d, (665, 160), 14, ACC, DARK, 3)


def cutie(d):
    d.rounded_rectangle([270, 190, 650, 410], 30, fill=METAL, outline=DARK, width=6)
    for x in range(320, 610, 45):
        d.line([(x, 205), (x, 395)], fill=DARK, width=4)
    d.rounded_rectangle([380, 140, 540, 200], 14, fill=MID, outline=DARK, width=5)
    d.rounded_rectangle([630, 235, 735, 365], 20, fill=MID, outline=DARK, width=5)
    d.rectangle([735, 290, 780, 310], fill=LIGHT, outline=DARK, width=3)
    c = (200, 300)
    _c(d, c, 160, MID, DARK, 6); _c(d, c, 105, DARK); _c(d, c, 70, LIGHT, METAL, 4); _c(d, c, 22, DARK)
    for k in range(8):
        _c(d, _pol(c, 133, k * 45), 11, LIGHT, DARK, 3)


TIPURI = {"disc": disc, "placute": pads, "alternator": alternator, "far": far, "amortizor": amortizor,
          "distributie": distributie, "capota": capota, "jante": janta, "anvelope": anvelopa,
          "volan": volan, "radiator": radiator, "cutie": cutie}


def ilustratie(tip):
    img = Image.new("RGB", (W, H), BG)
    TIPURI[tip](ImageDraw.Draw(img))
    return img
