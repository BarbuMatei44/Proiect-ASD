import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models

CATEGORII = [("Motor", "Motor"), ("Frâne", "Frâne"), ("Suspensie", "Suspensie"), ("Caroserie", "Caroserie"),
             ("Electrice", "Electrice"), ("Interior", "Interior"), ("Roți și anvelope", "Roți și anvelope"),
             ("Altele", "Altele")]
STARI = [("Nouă", "Nouă"), ("Second-hand", "Second-hand"), ("Recondiționată", "Recondiționată")]


class Migration(migrations.Migration):
    initial = True
    dependencies = [migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations = [
        migrations.CreateModel(
            name="Anunt",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("titlu", models.CharField(max_length=140)),
                ("descriere", models.TextField(blank=True)),
                ("categorie", models.CharField(choices=CATEGORII, max_length=40)),
                ("stare", models.CharField(choices=STARI, max_length=20)),
                ("marca", models.CharField(blank=True, max_length=60, verbose_name="Marcă")),
                ("model", models.CharField(blank=True, max_length=60)),
                ("an", models.PositiveSmallIntegerField(blank=True, null=True)),
                ("cod_piesa", models.CharField(blank=True, max_length=60, verbose_name="Cod piesă")),
                ("pret", models.DecimalField(decimal_places=2, max_digits=9, verbose_name="Preț (lei)")),
                ("oras", models.CharField(blank=True, max_length=80, verbose_name="Localitate")),
                ("telefon", models.CharField(blank=True, max_length=30)),
                ("imagine", models.ImageField(blank=True, upload_to="anunturi/", verbose_name="Fotografie")),
                ("creat", models.DateTimeField(auto_now_add=True)),
                ("user", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="anunturi",
                                           to=settings.AUTH_USER_MODEL)),
            ],
            options={"verbose_name_plural": "anunțuri", "ordering": ["-creat"]},
        ),
    ]
