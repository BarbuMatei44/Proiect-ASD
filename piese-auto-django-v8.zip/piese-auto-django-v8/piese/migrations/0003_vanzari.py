import django.db.models.deletion
import django.utils.timezone
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("piese", "0002_cerere_oferta"),
    ]
    operations = [
        migrations.AddField(model_name="anunt", name="vandut", field=models.BooleanField(default=False)),
        migrations.CreateModel(
            name="Vanzare",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("titlu", models.CharField(max_length=140)),
                ("categorie", models.CharField(blank=True, max_length=40)),
                ("marca", models.CharField(blank=True, max_length=60)),
                ("pret", models.DecimalField(decimal_places=2, max_digits=9, verbose_name="Preț final (lei)")),
                ("sursa", models.CharField(choices=[("anunt", "Anunț"), ("cerere", "Cerere")],
                                           default="anunt", max_length=10)),
                ("creat", models.DateTimeField(default=django.utils.timezone.now)),
                ("anunt", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL,
                                            related_name="vanzari", to="piese.anunt")),
                ("cerere", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL,
                                             related_name="vanzari", to="piese.cerere")),
                ("cumparator", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL,
                                                 related_name="cumparari", to=settings.AUTH_USER_MODEL)),
                ("vanzator", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL,
                                               related_name="vanzari", to=settings.AUTH_USER_MODEL)),
            ],
            options={"verbose_name_plural": "vânzări", "ordering": ["-creat"]},
        ),
    ]
