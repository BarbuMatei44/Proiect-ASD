from django.urls import path
from . import dashboard, views

urlpatterns = [
    path("", views.Acasa.as_view(), name="acasa"),
    path("anunturi/", views.Lista.as_view(), name="lista"),
    path("anunt/nou/", views.Nou.as_view(), name="nou"),
    path("anunt/<int:pk>/", views.Detaliu.as_view(), name="detaliu"),
    path("anunt/<int:pk>/editeaza/", views.Editeaza.as_view(), name="editeaza"),
    path("anunt/<int:pk>/sterge/", views.Sterge.as_view(), name="sterge"),
    path("anunt/<int:pk>/vandut/", views.marcheaza_vandut, name="anunt_vandut"),
    path("anunt/<int:pk>/disponibil/", views.marcheaza_disponibil, name="anunt_disponibil"),
    path("contul-meu/", dashboard.contul_meu, name="contul_meu"),
    path("contul-meu/export.csv", dashboard.export_csv_meu, name="contul_meu_csv"),
    path("dashboard/", dashboard.panou, name="dashboard"),
    path("dashboard/export.csv", dashboard.export_csv, name="dashboard_csv"),
    path("anunturile-mele/", views.AnunturileMele.as_view(), name="anunturile_mele"),
    path("cereri/", views.ListaCereri.as_view(), name="cereri"),
    path("cerere/noua/", views.CerereNoua.as_view(), name="cerere_noua"),
    path("cerere/<int:pk>/", views.CerereDetaliu.as_view(), name="cerere_detaliu"),
    path("cerere/<int:pk>/editeaza/", views.CerereEditeaza.as_view(), name="cerere_editeaza"),
    path("cerere/<int:pk>/sterge/", views.CerereSterge.as_view(), name="cerere_sterge"),
    path("cerere/<int:pk>/redeschide/", views.redeschide_cerere, name="cerere_redeschide"),
    path("oferta/<int:pk>/accepta/", views.accepta_oferta, name="oferta_accepta"),
    path("cererile-mele/", views.CererileMele.as_view(), name="cererile_mele"),
    path("inregistrare/", views.Inregistrare.as_view(), name="inregistrare"),
]
