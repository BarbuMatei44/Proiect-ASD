from django.core.exceptions import ValidationError


class ParolaComplexa:
    """Parola trebuie să aibă literă mare, literă mică, cifră și caracter special."""

    def validate(self, password, user=None):
        lipsa = []
        if not any(c.isupper() for c in password):
            lipsa.append("o literă mare")
        if not any(c.islower() for c in password):
            lipsa.append("o literă mică")
        if not any(c.isdecimal() for c in password):
            lipsa.append("o cifră")
        if not any(not c.isalnum() and not c.isspace() for c in password):
            lipsa.append("un caracter special (de exemplu ! ? # $ %)")
        if lipsa:
            raise ValidationError("Parola trebuie să mai conțină: " + ", ".join(lipsa) + ".", code="parola_slaba")

    def get_help_text(self):
        return "Parola trebuie să conțină literă mare, literă mică, cifră și caracter special."
