@echo off
cd /d "%~dp0"
title Piese Auto
rem Pune SEED=0 daca nu vrei anunturi si cereri demonstrative la prima pornire
set SEED=1

set PY=python
%PY% --version >nul 2>nul
if errorlevel 1 set PY=py
%PY% --version >nul 2>nul
if errorlevel 1 (
  echo Python nu este instalat.
  echo Descarca-l de la https://www.python.org/downloads/
  echo La instalare bifeaza "Add Python to PATH", apoi porneste din nou start.bat
  pause
  exit /b 1
)

if not exist venv\Scripts\python.exe (
  echo Prima pornire: instalez tot ce trebuie. Dureaza 1-3 minute si are nevoie de internet...
  %PY% -m venv venv || goto eroare
  venv\Scripts\python -m pip install -r requirements.txt || goto eroare
)

venv\Scripts\python manage.py migrate || goto eroare
if "%SEED%"=="1" if not exist db.seeded (
  venv\Scripts\python manage.py seed
  echo gata> db.seeded
)

echo.
echo Site-ul porneste la http://127.0.0.1:8000
echo Lasa aceasta fereastra deschisa. Ca sa opresti site-ul, inchide-o sau apasa Ctrl+C.
start "" /min cmd /c "ping -n 5 127.0.0.1 >nul & start http://127.0.0.1:8000"
venv\Scripts\python manage.py runserver 8000 --noreload
goto :eof

:eroare
echo.
echo A aparut o eroare. Copiaza textul de mai sus si trimite-l celui care ti-a dat site-ul.
pause
