#!/bin/bash
# Mac / Linux: dublu-click (Mac) sau ./start.command
cd "$(dirname "$0")"
SEED=1   # pune 0 daca nu vrei date demonstrative
command -v python3 >/dev/null || { echo "Instaleaza Python 3 de la python.org"; read -p "Enter..."; exit 1; }
if [ ! -x venv/bin/python ]; then
  echo "Prima pornire: instalez dependentele (1-3 minute, are nevoie de internet)..."
  python3 -m venv venv && venv/bin/python -m pip install -r requirements.txt || { read -p "Eroare. Enter..."; exit 1; }
fi
venv/bin/python manage.py migrate || { read -p "Eroare. Enter..."; exit 1; }
if [ "$SEED" = "1" ] && [ ! -f db.seeded ]; then venv/bin/python manage.py seed && echo gata > db.seeded; fi
(sleep 3; (open http://127.0.0.1:8000 || xdg-open http://127.0.0.1:8000) >/dev/null 2>&1) &
venv/bin/python manage.py runserver 8000 --noreload
